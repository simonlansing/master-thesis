import imp
import logging
import logging.config
import signal
import socket
import sys
import threading
import time

LOGGER = logging.getLogger(__name__)
logging.config.fileConfig("/mnt/hgfs/Src/1_servicemanager/logging.conf", disable_existing_loggers=False)

networking = None
try:
    file, pathname, description = imp.find_module('utils_network_functions', ['./', '../', '../1_servicemanager/server/', '/mnt/hgfs/Src/1_servicemanager/server/'])
except ImportError as exc:
    LOGGER.info(exc)
    sys.exit(1)
else:
    try:
        networking = imp.load_module('utils_network_functions', file, pathname, description)
    except ImportError as exc:
        LOGGER.info(exc)
        sys.exit(1)

def signal_handler(signal, frame):
    LOGGER.info("Ctrl+C pressed")
    sys.exit(0)

class PerformanceService(object):

    def __init__(self):
        LOGGER.debug("performance service init")

        self.stop_service_event = threading.Event()

        self.tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.tcp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.client_threads = []
        tcp_service_thread = threading.Thread(target=self.run_tcp_service_port,
                                              args=(self.tcp_socket,
                                                    5000, self.handle_tcp_packets,))
        tcp_service_thread.daemon = True
        tcp_service_thread.start()


        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        udp_service_thread = threading.Thread(target=self.run_udp_service_port,
                                              args=(self.udp_socket,
                                                    5001, self.handle_udp_packets,))
        udp_service_thread.daemon = True
        udp_service_thread.start()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        LOGGER.debug('performance service exit')
        self.stop_service_event.set()        
        self.tcp_socket.close()

        for thread in self.client_threads:
            LOGGER.info("wait for thread")
            thread.join()

        LOGGER.debug('performance service stops now')
        return self

    def handle_udp_packets(self, udp_socket, msg, addr):
        LOGGER.info('UDP connection on port 5001')
        udp_socket.sendto("OK", addr)

    def run_udp_service_port(self, udp_socket, port, handle_function):
        #LOGGER.debug('service handler run_service_port: ' + str(port))

        try:
            udp_socket.bind(('', port))
            #backlog is set to default value. defined in /proc/sys/net/core/somaxconn
        except socket.error as e:
            LOGGER.error('Failed to bind service sockets (socket.error): ' + str(e), exc_info=True)
        except Exception as e:
            LOGGER.error('Failed to bind service sockets: ' + str(e), exc_info=True)

        while self.stop_service_event.is_set() is False:
            try:
                msg, addr = udp_socket.recvfrom(1024)
                LOGGER.info('Message from ' + addr + '=' + str(msg))
                connected_client_thread = threading.Thread(target=handle_function, args=(udp_socket, msg, addr,))
                connected_client_thread.start()

                self.client_threads.append(connected_client_thread)
            except socket.error as e:
                LOGGER.error('Failed to get message (socket.error): ' + str(e), exc_info=True)
            except Exception as e:
                LOGGER.error('Failed to get message: ' + str(e), exc_info=True)
        return


    def handle_tcp_packets(self, conn):
        #LOGGER.info('TCP connection on port 5000')
        message = networking.recv_packed(conn)
        
        networking.send_packed(conn, "OK")
        conn.close()

    def run_tcp_service_port(self, tcp_socket, port, handle_function):
        #LOGGER.debug('service handler run_service_port: ' + str(port))

        try:
            tcp_socket.bind(('', port))
            #backlog is set to default value. defined in /proc/sys/net/core/somaxconn
            tcp_socket.listen(128)
        except socket.error as e:
            LOGGER.error('Failed to bind service sockets (socket.error): ' + str(e), exc_info=True)
        except Exception as e:
            LOGGER.error('Failed to bind service sockets: ' + str(e), exc_info=True)

        while self.stop_service_event.is_set() is False:
            try:
                conn, addr = tcp_socket.accept()
                #LOGGER.info('Connected with ' + addr[0] + ':' + str(addr[1]))
                connected_client_thread = threading.Thread(target=handle_function, args=(conn,))
                connected_client_thread.start()
                
                self.client_threads.append(connected_client_thread)
            except socket.error as e:
                LOGGER.error('Failed to accept socket (socket.error): ' + str(e), exc_info=True)
            except Exception as e:
                LOGGER.error('Failed to accept socket: ' + str(e), exc_info=True)
        return

    def run(self):
        while True:
            time.sleep(0.001)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)

    with PerformanceService() as performance_service:
        performance_service.run()
        